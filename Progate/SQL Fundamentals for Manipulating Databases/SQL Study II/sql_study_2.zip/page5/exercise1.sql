-- dapatkan jumlah baris dikolom name dari table purchases 
SELECT COUNT(name)
FROM purchases;